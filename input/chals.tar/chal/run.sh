# challenge: "flag_guesser"
NSJAIL_PORT=31337
LANDING_PORT=31338


# build the challenge
gcc main.c

cp a.out /bin/flag_guesser

# setup the flag_guesser folder
rm ../workshop/flag_guesser/*
cp a.out ../workshop/flag_guesser/flag_guesser
sed -E "s/FLAG=flag\{[0-9A-Z-]+\}/FLAG=localtestflag/g" run.sh > ../workshop/flag_guesser/run.sh

# upon pressing C-c, kill the python server as well
trap 'kill $BGPID; exit' INT

pushd ../workshop/flag_guesser
python3 -m http.server $LANDING_PORT &
BGPID=$!
popd

# run the challenge within nsjail
nsjail \
	-Ml \
	--port $NSJAIL_PORT \
	--chroot / \
	-E FLAG=flag{CA96AA55-2DC8-4F71-92CA-C45CB6A3AAB0} \
	--user 1337 \
	--group 1337 \
	--stderr_to_null \
	-- /bin/flag_guesser
