{
  description = "ctf";
  nixConfig.bash-prompt = "\[ctf\]; ";

  inputs = {
    nixpkgs.url = "git+https://github.com/nixos/nixpkgs.git?shallow=1&ref=nixos-24.11";
  };

  # Flake outputs
  outputs =
    { nixpkgs, ... }:
    let
      # Systems supported
      allSystems = [
        "x86_64-linux" # 64-bit Intel/AMD Linux
        "aarch64-linux" # 64-bit ARM Linux
        "x86_64-darwin" # 64-bit Intel macOS
        "aarch64-darwin" # 64-bit ARM macOS
      ];

      # Helper to provide system-specific attributes
      nameValuePair = name: value: { inherit name value; };
      genAttrs = names: f: builtins.listToAttrs (map (n: nameValuePair n (f n)) names);
      forAllSystems = f: genAttrs allSystems (system: f { pkgs = import nixpkgs { inherit system; }; });
    in
    {
      # Development environment output
      devShells = forAllSystems (
        { pkgs }:
        {
          default =
            let
              python = pkgs.python311; # Use Python 3.11
            in
            pkgs.mkShell {
              packages =
                with pkgs;
                [ gcc pwndbg ]
                ++ [
                  # Python plus helper tools
                  (python.withPackages (
                    ps: with ps; [
                      pwntools
                      pwndbg
                      pycryptodome
                    ]
                  ))
                ];
            };
        }
      );
    };
}
