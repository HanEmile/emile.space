from pwn import *

p = process("./a.out")

p.interactive()
