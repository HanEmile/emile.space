# challenge: "calc"
NSJAIL_PORT=31335
LANDING_PORT=31336


# build the challenge
gcc -O0 main.c

cp a.out /bin/calc

# setup the shared folder
rm ../workshop/calc/*
cp a.out ../workshop/calc/calc
cp main.c ../workshop/calc/main.c
sed -E "s/FLAG=flag\{[0-9A-Z-]+\}/FLAG=localtestflag/g" run.sh > ../workshop/calc/run.sh

# upon pressing C-c, kill the python server as well
trap 'kill $BGPID; exit' INT

pushd ../workshop/calc
python3 -m http.server $LANDING_PORT &
BGPID=$!
popd

# run the challenge within nsjail
nsjail \
	-Ml \
	--port $NSJAIL_PORT \
	--chroot / \
	-E FLAG=flag{74267A6B-9C20-49E2-8AF3-EA6C6A4263CB} \
	--user 1337 \
	--group 1337 \
	--stderr_to_null \
	-- /bin/calc
