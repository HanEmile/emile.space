# challenge: "calc"
NSJAIL_PORT=31335
LANDING_PORT=31336


# build the challenge
gcc main.c

cp a.out /bin/calc

# setup the shared folder
rm ./shared/*
cp a.out ./shared/calc
cp main.c ./shared/calc
sed -E "s/FLAG=flag\{[0-9A-Z-]+\}/FLAG=localtestflag/g" run.sh > ./shared/run.sh

# upon pressing C-c, kill the python server as well
trap 'kill $BGPID; exit' INT

pushd ./shared
python3 -m http.server $LANDING_PORT &
BGPID=$!
popd

# run the challenge within nsjail
nsjail \
	-Ml \
	--port $NSJAIL_PORT \
	--chroot / \
	-E FLAG=localtestflag \
	--user 1337 \
	--group 1337 \
	--stderr_to_null \
	-- /bin/calc
